<?php
// Frontend/ADMIN/settings.php  (OOP refactored)
require_once '../../Frontend/Core/SettingsView.php';
$view = new SettingsView();   // dispatches ?ajax and POST backup/restore early

// Variable aliases
$message = $view->message;
$msgType = $view->msgType;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22 fill=%22%23ff69b4%22>♛</text></svg>">
  <title>Empress' Cafe Boracay</title>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
  <link rel="stylesheet" href="../dist/css/empress-cafe-theme.css">
  <style>
    body, .main-header.navbar { transition: background-color .5s ease, color .5s ease; }
    #darkModeToggle           { transition: box-shadow .3s ease; }
    
    #darkModeToggle.clicked   { box-shadow: 0 0 15px rgba(255,255,255,.8); }
    

    /* Settings Cards */
    .settings-section-title {
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: #aaa;
      margin-bottom: 12px;
      margin-top: 8px;
    }

    .backup-icon-wrap {
      width: 60px;
      height: 60px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.6rem;
      margin-right: 16px;
      flex-shrink: 0;
    }
    .backup-icon-wrap.green  { background: rgba(40,167,69,.15);  color: #28a745; }
    .backup-icon-wrap.blue   { background: rgba(23,162,184,.15); color: #17a2b8; }
    .backup-icon-wrap.yellow { background: rgba(255,193,7,.15);  color: #ffc107; }
    .backup-icon-wrap.pink   { background: rgba(233,30,140,.15); color: #e91e8c; }

    .action-card {
      border-radius: 12px;
      border: none;
      transition: transform .2s, box-shadow .2s;
    }
    .action-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0,0,0,.25) !important;
    }

    /* Drop zone */
    #dropZone {
      border: 2px dashed #444;
      border-radius: 12px;
      padding: 32px;
      text-align: center;
      cursor: pointer;
      transition: border-color .2s, background .2s;
    }
    #dropZone.dragover {
      border-color: #17a2b8;
      background: rgba(23,162,184,.07);
    }
    #dropZone i { font-size: 2.5rem; color: #666; margin-bottom: 8px; display: block; }

    /* Progress bar animation */
    .backup-progress { display: none; }
    @keyframes pulse-bar {
      0%   { opacity: 1; }
      50%  { opacity: .5; }
      100% { opacity: 1; }
    }
    .progress-bar.animated-pulse { animation: pulse-bar 1s infinite; }

    /* Timeline for backup history */
    .backup-timeline .item {
      display: flex;
      align-items: center;
      padding: 10px 0;
      border-bottom: 1px solid rgba(255,255,255,.06);
    }
    .backup-timeline .item:last-child { border-bottom: none; }
    .backup-timeline .item .dot {
      width: 10px; height: 10px;
      border-radius: 50%;
      margin-right: 12px;
      flex-shrink: 0;
    }
    .dot-success     { background: #28a745; }
    .dot-restore     { background: #17a2b8; }
    .dot-restore_warn{ background: #ffc107; }

    @keyframes logItemIn {
      from { opacity: 0; transform: translateX(-12px); background: rgba(233,30,140,.13); }
      to   { opacity: 1; transform: translateX(0);     background: transparent; }
    }
    .backup-timeline .item.rt-new {
      animation: logItemIn .5s ease forwards;
    }
  
    
    /* FIX: Table hover visible in light mode */
    body:not(.dark-mode) .table tbody tr:hover { background-color: rgba(233,30,140,0.08) !important; }
    body:not(.dark-mode) .table tbody tr:hover td { color: #212529 !important; }

    /* FIX: table-dark class invisible in light mode — keep text readable */
    body:not(.dark-mode) .table-dark,
    body:not(.dark-mode) .table-dark th,
    body:not(.dark-mode) .table-dark td,
    body:not(.dark-mode) .table-dark thead th {
      background-color: transparent !important;
      color: #212529 !important;
      border-color: #dee2e6 !important;
    }

    /* ══════════════════════════════════════════════════════
       GLOBAL FIXES — icon animations removed + mobile scrollbar
       ══════════════════════════════════════════════════════ */

    /* 1. Kill ALL icon animations — every selector possible */
    i.fas, i.far, i.fab, i.fal, i.fad,
    .nav-icon,
    .info-box-icon i,
    .btn i,
    .card-title i,
    .sidebar i,
    [class*="fa-"] {
      animation: none !important;
      -webkit-animation: none !important;
      transform: none !important;
      /* allow color/opacity transitions on non-icon elements still */
    }
    .fa-spin, .fa-pulse {
      animation: none !important;
      -webkit-animation: none !important;
    }
    .info-box-icon, .info-box-icon *,
    .small-box .icon i, .small-box .icon [class*="fa-"] {
      animation: none !important;
      -webkit-animation: none !important;
      transform: none !important;
    }

    /* 2. TABLE MOBILE SCROLL FIX
          - Tables MUST NOT wrap text vertically.
          - The wrapper scrolls horizontally; cells stay single-line.   */
    .table-responsive {
      overflow-x: auto !important;
      -webkit-overflow-scrolling: touch;
    }
    /* DataTables also need their own wrapper to scroll */
    .dataTables_wrapper {
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }
    /* CRITICAL: keep all table text on one line — table scrolls, text never wraps */
    .table td,
    .table th {
      white-space: nowrap !important;
      word-break: normal !important;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 220px;        /* prevents insanely wide single cells */
    }
    /* Allow description/notes columns to be slightly wider but still nowrap */
    .table td:nth-child(4),
    .table td.desc-col {
      max-width: 280px;
    }

    /* 3. Pagination scrolls on small screens */
    .dataTables_wrapper .dataTables_paginate {
      overflow-x: auto;
      white-space: nowrap;
      display: block;
      padding-bottom: 6px;
    }

    /* 4. Custom thin scrollbar (WebKit) — pink accent */
    ::-webkit-scrollbar        { height: 6px; width: 6px; }
    ::-webkit-scrollbar-track  { background: rgba(0,0,0,0.06); border-radius: 3px; }
    ::-webkit-scrollbar-thumb  { background: rgba(233,30,140,0.45); border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(233,30,140,0.75); }

    /* 5. Content wrapper horizontal scroll guard */
    .content-wrapper {
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }
    html { overflow-y: scroll; }

    /* 6. Mobile tweaks */
    @media (max-width: 576px) {
      .dataTables_wrapper .dataTables_paginate .paginate_button {
        padding: 3px 6px !important;
        font-size: 11px !important;
        min-width: 26px;
      }
      .dataTables_wrapper .dataTables_length,
      .dataTables_wrapper .dataTables_filter,
      .dataTables_wrapper .dataTables_info {
        font-size: 11px;
      }
      .content-header h1 { font-size: 1.2rem; }
    }

</style>
<style>
@keyframes rtPulse{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 7px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
</style>
</head>
<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">

  <!-- ── Navbar ─────────────────────────────────────────────── -->
  <nav class="main-header navbar navbar-expand navbar-dark">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index2.php" class="nav-link">Home</a>
      </li>
    </ul>
       <ul class="navbar-nav ml-auto">
<li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button"><i class="fas fa-expand-arrows-alt"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" id="darkModeToggle" href="#" role="button"><i class="fas fa-moon"></i></a>
      </li>
    </ul>
  </nav>

  <!-- ── Sidebar ───────────────────────────────────────────── -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link">
      <img src="../dist/img/Empress' Cafe Boracay.jpg" alt="Logo" class="brand-image img-circle elevation-3" style="opacity:.8">
      <span class="brand-text font-weight-light">Empress' Cafe</span>
    </a>
    <div class="sidebar">
      <?php
        $admin_image = $_SESSION['image'] ?? '';
        $admin_first = $_SESSION['firstname'] ?? '';
        $admin_last  = $_SESSION['lastname']  ?? '';
        if (empty($admin_first)) {
            $admin_first = strpos($_SESSION['user'] ?? '', '@') !== false
                ? explode('@', $_SESSION['user'])[0]
                : ($_SESSION['user'] ?? 'Admin');
        }
        $admin_name  = htmlspecialchars(trim($admin_first . ' ' . $admin_last));
        $admin_photo = !empty($admin_image)
            ? '../../' . htmlspecialchars($admin_image)
            : '../dist/img/avatar.png';
      ?>
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image"><img src="<?= $admin_photo ?>" class="img-circle elevation-2" alt="<?= $admin_name ?>"></div>
        <div class="info">
          <a href="#" class="d-block"><?= $admin_name ?></a>
        </div>
      </div>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item"><a href="./index2.php"          class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>Overview</p></a></li>
          <li class="nav-item"><a href="./menu-management.php" class="nav-link"><i class="nav-icon fas fa-utensils"></i><p>Menu Management</p></a></li>
          <li class="nav-item"><a href="./inventory.php"       class="nav-link"><i class="nav-icon fas fa-boxes"></i><p>Inventory Tracking</p></a></li>
          <li class="nav-item"><a href="./suppliers.php"       class="nav-link"><i class="nav-icon fas fa-truck"></i><p>Supplier Info</p></a></li>
          <li class="nav-item"><a href="./staff-list.php"      class="nav-link"><i class="far fa-user nav-icon"></i><p>Staff List</p></a></li>
          <li class="nav-item"><a href="./sale_revenue.php"    class="nav-link"><i class="nav-icon fas fa-chart-line"></i><p>Sales &amp; Revenue</p></a></li>
          <li class="nav-item"><a href="./report.php"          class="nav-link"><i class="nav-icon fas fa-file-alt"></i><p>Reports</p></a></li>
          <li class="nav-item"><a href="./void_refund.php"     class="nav-link"><i class="nav-icon fas fa-undo-alt"></i><p>Void &amp; Refund</p></a></li>
          <li class="nav-item"><a href="./settings.php"        class="nav-link active"><i class="nav-icon fas fa-cog"></i><p>Settings</p></a></li>
          <li class="nav-item mt-auto"><a href="../../Backend/Controllers/LogoutController.php" class="nav-link"><i class="nav-icon fas fa-sign-out-alt"></i><p>Log Out</p></a></li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- ── Content Wrapper ───────────────────────────────────── -->
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><i class="fas fa-cog mr-2"></i>Settings</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index2.php">Home</a></li>
              <li class="breadcrumb-item active">Settings</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <section class="content">
      <div class="container-fluid">

        <!-- ── Alert Messages ──────────────────────────────── -->
        <?php if ($message): ?>
        <div class="alert alert-<?= $msgType ?> alert-dismissible fade show" role="alert">
          <i class="fas fa-<?= $msgType === 'success' ? 'check-circle' : ($msgType === 'danger' ? 'times-circle' : 'exclamation-triangle') ?> mr-2"></i>
          <?= htmlspecialchars($message) ?>
          <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
        </div>
        <?php endif; ?>

        <!-- ── BACKUP & RESTORE SECTION ────────────────────── -->
        <div class="settings-section-title"><i class="fas fa-database mr-1"></i> Data Backup &amp; Restore</div>

        <div class="row">

          <!-- Backup Card -->
          <div class="col-md-6 col-lg-4 mb-4">
            <div class="card action-card elevation-2 h-100">
              <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                  <div class="backup-icon-wrap green">
                    <i class="fas fa-download"></i>
                  </div>
                  <div>
                    <h5 class="mb-0 font-weight-bold">Download Backup</h5>
                    <small class="text-muted">Export full database as .sql file</small>
                  </div>
                </div>
                <p class="text-muted small mb-3">
                  Back up all your data — orders, menu, inventory, staff, suppliers, and reports.
                  Save it to your computer to keep your data safe.
                </p>

                <!-- Progress bar (shown during backup) -->
                <div class="backup-progress mb-3" id="backupProgress">
                  <div class="progress" style="height:6px; border-radius:4px;">
                    <div class="progress-bar bg-success animated-pulse" style="width:100%"></div>
                  </div>
                  <small class="text-muted mt-1 d-block text-center">Generating backup file…</small>
                </div>

                <form method="POST" id="backupForm">
                  <input type="hidden" name="action" value="backup">
                  <button type="submit" class="btn btn-success btn-block" id="backupBtn" onclick="startBackup()">
                    <i class="fas fa-download mr-2"></i>Download Backup Now
                  </button>
                </form>
              </div>
              <div class="card-footer" style="background:rgba(40,167,69,.07); border-top:1px solid rgba(40,167,69,.15);">
                <small class="text-muted"><i class="fas fa-info-circle mr-1"></i>
                  Recommended: backup weekly or before any major changes.
                </small>
              </div>
            </div>
          </div>

          <!-- Restore Card -->
          <div class="col-md-6 col-lg-4 mb-4">
            <div class="card action-card elevation-2 h-100">
              <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                  <div class="backup-icon-wrap blue">
                    <i class="fas fa-upload"></i>
                  </div>
                  <div>
                    <h5 class="mb-0 font-weight-bold">Restore Backup</h5>
                    <small class="text-muted">Import a previous .sql backup file</small>
                  </div>
                </div>
                <p class="text-muted small mb-3">
                  If data is lost or something goes wrong, upload your backup file to recover everything.
                </p>

                <form method="POST" enctype="multipart/form-data" id="restoreForm" onsubmit="return confirmRestore()">
                  <input type="hidden" name="action" value="restore">

                  <!-- Drop Zone -->
                  <div id="dropZone" onclick="document.getElementById('backupFile').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <div id="dropText">
                      <strong>Click or drag &amp; drop</strong><br>
                      <small class="text-muted">your .sql backup file here</small>
                    </div>
                    <div id="fileChosen" class="text-info mt-2" style="display:none;">
                      <i class="fas fa-file-code mr-1"></i><span id="chosenName"></span>
                    </div>
                  </div>
                  <input type="file" name="backup_file" id="backupFile" accept=".sql" style="display:none;" onchange="fileSelected(this)">

                  <button type="submit" class="btn btn-info btn-block mt-3" id="restoreBtn" disabled>
                    <i class="fas fa-redo mr-2"></i>Restore Database
                  </button>
                </form>
              </div>
              <div class="card-footer" style="background:rgba(23,162,184,.07); border-top:1px solid rgba(23,162,184,.15);">
                <small class="text-warning"><i class="fas fa-exclamation-triangle mr-1"></i>
                  Warning: This will overwrite current data. Make sure to backup first!
                </small>
              </div>
            </div>
          </div>

          <!-- Tips Card -->
          <div class="col-md-6 col-lg-4 mb-4">
            <div class="card action-card elevation-2 h-100">
              <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                  <div class="backup-icon-wrap yellow">
                    <i class="fas fa-lightbulb"></i>
                  </div>
                  <div>
                    <h5 class="mb-0 font-weight-bold">Backup Tips</h5>
                    <small class="text-muted">Best practices for data safety</small>
                  </div>
                </div>
                <ul class="list-unstyled small text-muted mb-0">
                  <li class="mb-2"><i class="fas fa-check-circle text-success mr-2"></i>Back up <strong>every week</strong> or before any updates</li>
                  <li class="mb-2"><i class="fas fa-check-circle text-success mr-2"></i>Save the .sql file to <strong>Google Drive or USB</strong></li>
                  <li class="mb-2"><i class="fas fa-check-circle text-success mr-2"></i>Always back up <strong>before restoring</strong> to stay safe</li>
                  <li class="mb-2"><i class="fas fa-check-circle text-success mr-2"></i>The backup file is <strong>confidential</strong> — do not share it</li>
                  <li class="mb-2"><i class="fas fa-check-circle text-success mr-2"></i>I-check ang filename — format: <code>empress_cafe_backup_YYYYMMDD.sql</code></li>
                </ul>
              </div>
              <div class="card-footer" style="background:rgba(255,193,7,.07); border-top:1px solid rgba(255,193,7,.15);">
                <small class="text-muted"><i class="fas fa-shield-alt mr-1 text-warning"></i>
                  Your backup contains all sensitive business data.
                </small>
              </div>
            </div>
          </div>

        </div><!-- end row -->

        <!-- ── Backup History (session-based) ──────────────── -->
        <div class="settings-section-title mt-2"><i class="fas fa-history mr-1"></i> Activity Log</div>
        <div class="row">
          <div class="col-md-8 mb-4">
            <div class="card elevation-2" style="border-radius:12px; border:none;">
              <div class="card-header d-flex align-items-center justify-content-between">
                <h6 class="mb-0">
                  <i class="fas fa-list-alt mr-2"></i>Recent Backup / Restore Activity
                  <span id="logLiveDot" style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#22c55e;vertical-align:middle;margin-left:6px;" title="Live"></span>
                </h6>
                <div class="d-flex align-items-center" style="gap:10px;">
                  <small class="text-muted" id="logLastUpdated" style="font-size:11px;"></small>
                  <button class="btn btn-sm btn-outline-secondary" id="clearLogBtn">
                    <i class="fas fa-trash-alt mr-1"></i>Clear Log
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div class="backup-timeline" id="activityLog">
                  <div class="text-muted text-center py-3" id="emptyLog">
                    <i class="fas fa-inbox fa-2x mb-2 d-block" style="color:#444;"></i>
                    No activity yet. Click "Download Backup" to get started.
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- ── APPEARANCE SETTINGS ──────────────── -->
          <div class="col-md-4 mb-4">
            <div class="card elevation-2" style="border-radius:12px; border:none;">
              <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-palette mr-2"></i>Appearance</h6>
              </div>
              <div class="card-body">
                <div class="d-flex align-items-center justify-content-between mb-3">
                  <div>
                    <strong>Dark Mode</strong><br>
                    <small class="text-muted">Toggle dark/light theme</small>
                  </div>
                  <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="darkModeSwitch" onchange="toggleDarkMode(this)">
                    <label class="custom-control-label" for="darkModeSwitch"></label>
                  </div>
                </div>
                <hr style="border-color:rgba(255,255,255,.08);">
                <div class="d-flex align-items-center justify-content-between">
                  <div>
                    <strong>Current User</strong><br>
                    <small class="text-muted">Logged in as</small>
                  </div>
                  <span class="badge badge-pink p-2">
                    <i class="fas fa-user mr-1"></i><?= htmlspecialchars($_SESSION['user'] ?? 'Admin') ?>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /.container-fluid -->
    </section>
  </div><!-- /.content-wrapper -->

</div><!-- /.wrapper -->

<!-- ── Confirm Restore Modal ─────────────────────────────────── -->
<div class="modal fade" id="confirmRestoreModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:16px; border:none;">
      <div class="modal-header" style="background:rgba(220,53,69,.1); border-bottom:1px solid rgba(220,53,69,.2); border-radius:16px 16px 0 0;">
        <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle mr-2"></i>Confirm Restore</h5>
        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
      </div>
      <div class="modal-body">
        <p class="mb-2"><strong>Are you sure you want to restore?</strong></p>
        <p class="text-muted small">
          This action will <strong>overwrite all current data</strong> with your backup file.
          This cannot be undone unless you have a new backup.
        </p>
        <div class="alert alert-warning py-2 small">
          <i class="fas fa-save mr-1"></i>
          <strong>Tip:</strong> Download the current backup before restoring!
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" onclick="proceedRestore()">
          <i class="fas fa-redo mr-1"></i>Yes, Restore Now
        </button>
      </div>
    </div>
  </div>
</div>

<!-- ── Scripts ──────────────────────────────────────────────── -->
<script src="../plugins/jquery/jquery.min.js"></script>
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="../dist/js/adminlte.js"></script>

<script>
// ── Dark Mode ──────────────────────────────────────────────────
$(function () {
  var dm = localStorage.getItem('darkMode');
  var isDark = dm !== 'false';
  applyDarkMode(isDark);
  $('#darkModeSwitch').prop('checked', isDark);

  $('#darkModeToggle').on('click', function (e) {
    e.preventDefault();
    var nowDark = $('body').hasClass('dark-mode');
    applyDarkMode(!nowDark);
    $('#darkModeSwitch').prop('checked', !nowDark);
    localStorage.setItem('darkMode', !nowDark);
    $(this).addClass('clicked');
    setTimeout(() => $(this).removeClass('clicked'), 300);
  });
});

function applyDarkMode(enable) {
  if (enable) {
    $('body').addClass('dark-mode');
    $('.main-header.navbar').addClass('navbar-dark').removeClass('navbar-white navbar-light bg-white');
    $('#darkModeToggle i').removeClass('fa-moon').addClass('fa-sun');
    localStorage.setItem('darkMode', 'true');
  } else {
    $('body').removeClass('dark-mode');
    $('.main-header.navbar').removeClass('navbar-dark').addClass('navbar-white navbar-light bg-white');
    $('#darkModeToggle i').removeClass('fa-sun').addClass('fa-moon');
    localStorage.setItem('darkMode', 'false');
  }
}

function toggleDarkMode(el) {
  applyDarkMode(el.checked);
}

// ── Drag & Drop ────────────────────────────────────────────────
var dropZone = document.getElementById('dropZone');
dropZone.addEventListener('dragover', function(e) {
  e.preventDefault();
  dropZone.classList.add('dragover');
});
dropZone.addEventListener('dragleave', function() {
  dropZone.classList.remove('dragover');
});
dropZone.addEventListener('drop', function(e) {
  e.preventDefault();
  dropZone.classList.remove('dragover');
  var file = e.dataTransfer.files[0];
  if (file) {
    var dt = new DataTransfer();
    dt.items.add(file);
    document.getElementById('backupFile').files = dt.files;
    fileSelected({ files: [file] });
  }
});

function fileSelected(input) {
  var file = input.files[0];
  if (file) {
    document.getElementById('chosenName').textContent = file.name;
    document.getElementById('dropText').style.display = 'none';
    document.getElementById('fileChosen').style.display = 'block';
    document.getElementById('restoreBtn').disabled = false;
  }
}

// ── Restore Confirm ────────────────────────────────────────────
function confirmRestore() {
  $('#confirmRestoreModal').modal('show');
  return false;
}

function proceedRestore() {
  $('#confirmRestoreModal').modal('hide');
  addLog('restore', 'Restore initiated from backup file');
  document.getElementById('restoreForm').submit();
}

// ── Backup progress animation ──────────────────────────────────
function startBackup() {
  // Show progress UI after a short delay so the form submission fires first
  setTimeout(function() {
    document.getElementById('backupProgress').style.display = 'block';
    document.getElementById('backupBtn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Generating…';
  }, 100);
  addLog('backup', 'Database backup downloaded');
  setTimeout(function() {
    document.getElementById('backupProgress').style.display = 'none';
    document.getElementById('backupBtn').innerHTML = '<i class="fas fa-download mr-2"></i>Download Backup Now';
  }, 3500);
}

// ── Activity Log — Real-Time (server-side session) ─────────────
(function(){
  'use strict';

  var POLL_MS   = 10000;   // poll every 10 seconds
  var _lastTs   = 0;       // timestamp of newest entry we've seen
  var _polling  = null;

  var dot       = document.getElementById('logLiveDot');
  var tsEl      = document.getElementById('logLastUpdated');
  var container = document.getElementById('activityLog');
  var emptyEl   = document.getElementById('emptyLog');
  var clearBtn  = document.getElementById('clearLogBtn');

  function setDot(ok) {
    if (!dot) return;
    dot.style.background = ok ? '#22c55e' : '#ef4444';
    dot.title = ok ? 'Live — connected' : 'Live — reconnecting…';
  }

  function escHtml(t) {
    return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function typeConfig(type) {
    var map = {
      backup:       { dot: 'dot-success',      icon: 'fa-download text-success',  label: 'Backup' },
      restore:      { dot: 'dot-restore',       icon: 'fa-upload text-info',       label: 'Restore' },
      restore_warn: { dot: 'dot-restore_warn',  icon: 'fa-exclamation-triangle text-warning', label: 'Restore (warnings)' },
    };
    return map[type] || { dot: 'dot-success', icon: 'fa-circle text-muted', label: type };
  }

  function renderLog(entries, highlightNew) {
    if (!container) return;

    // Remove old rendered items
    container.querySelectorAll('.item').forEach(function(el){ el.remove(); });

    if (!entries || entries.length === 0) {
      if (emptyEl) emptyEl.style.display = 'block';
      return;
    }
    if (emptyEl) emptyEl.style.display = 'none';

    entries.forEach(function(entry, idx) {
      var cfg = typeConfig(entry.type);
      var isNew = highlightNew && entry.ts > _lastTs;
      var div = document.createElement('div');
      div.className = 'item' + (isNew ? ' rt-new' : '');
      div.innerHTML =
        '<div class="dot ' + cfg.dot + '"></div>' +
        '<div class="flex-grow-1">' +
          '<strong><i class="fas ' + cfg.icon + ' mr-1"></i>' + escHtml(entry.msg) + '</strong>' +
          '<br><small class="text-muted">' +
            '<i class="fas fa-user mr-1" style="opacity:.5;"></i>' + escHtml(entry.user) +
            ' &nbsp;·&nbsp; ' + escHtml(entry.time) +
          '</small>' +
        '</div>';
      container.insertBefore(div, emptyEl);
    });

    // Update _lastTs to the most recent entry
    if (highlightNew && entries.length > 0) {
      _lastTs = Math.max(_lastTs, entries[0].ts || 0);
    }
  }

  function updateTimestamp() {
    if (tsEl) {
      var now = new Date();
      tsEl.textContent = 'Updated ' + now.toLocaleTimeString('en-PH', {hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:true});
    }
  }

  function fetchLog(isFirst) {
    fetch('settings.php?ajax=get_log', {cache: 'no-store'})
      .then(function(r){ return r.json(); })
      .then(function(data) {
        setDot(true);
        renderLog(data.log || [], !isFirst);
        if (isFirst && data.log && data.log.length > 0) {
          _lastTs = data.log[0].ts || 0;
        }
        updateTimestamp();
      })
      .catch(function(){ setDot(false); });
  }

  // ── Public: add entry via server (called after backup/restore events) ──
  window.addServerLog = function(type, msg) {
    fetch('settings.php?ajax=add_log', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'type=' + encodeURIComponent(type) + '&msg=' + encodeURIComponent(msg)
    })
    .then(function(){ fetchLog(false); })
    .catch(function(){});
  };

  // ── Clear log ──────────────────────────────────────────────────
  if (clearBtn) {
    clearBtn.addEventListener('click', function() {
      fetch('settings.php?ajax=clear_log', {method: 'POST', cache: 'no-store'})
        .then(function(){ _lastTs = 0; fetchLog(true); })
        .catch(function(){});
    });
  }

  // ── Start ──────────────────────────────────────────────────────
  $(function() {
    fetchLog(true);
    _polling = setInterval(function(){ fetchLog(false); }, POLL_MS);

    // If page loaded after a restore POST, log is already saved server-side
    // Just fetch — no need to call addServerLog again
  });

})();

// ── Legacy stubs so existing onclick calls don't break ─────────
function addLog(type, msg) { if (window.addServerLog) window.addServerLog(type, msg); }
function clearLog() { document.getElementById('clearLogBtn') && document.getElementById('clearLogBtn').click(); }
function escHtml(t) { return String(t).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

</script>



<!-- ══ NEW ORDER REAL-TIME NOTIFICATION (SSE) ══════════════════════ -->
<div id="newOrderToast" style="
  display:none;position:fixed;bottom:24px;right:24px;z-index:99999;
  min-width:300px;max-width:360px;
  background:linear-gradient(135deg,#e91e8c 0%,#9c27b0 100%);
  color:#fff;border-radius:14px;
  box-shadow:0 8px 32px rgba(233,30,140,.45);
  padding:16px 20px;font-family:'Source Sans Pro',sans-serif;
  animation:toastSlideIn .35s cubic-bezier(.22,1,.36,1);
">
  <div style="display:flex;align-items:flex-start;gap:12px;">
    <div style="font-size:1.6rem;line-height:1;">🛎️</div>
    <div style="flex:1;">
      <div style="font-weight:700;font-size:.95rem;margin-bottom:2px;">New Order Received!</div>
      <div id="noToastMsg" style="font-size:.82rem;opacity:.9;">A new order just came in.</div>
    </div>
    <button onclick="document.getElementById('newOrderToast').style.display='none'"
      style="background:none;border:none;color:#fff;font-size:1.1rem;cursor:pointer;padding:0;line-height:1;opacity:.8;">✕</button>
  </div>
  <div style="margin-top:10px;display:flex;gap:8px;">
    <div id="noToastOrderBadge" style="background:rgba(255,255,255,.2);border-radius:20px;padding:3px 10px;font-size:.78rem;font-weight:600;"></div>
    <div id="noToastTimeBadge"  style="background:rgba(255,255,255,.15);border-radius:20px;padding:3px 10px;font-size:.78rem;"></div>
  </div>
</div>
<style>
@keyframes toastSlideIn{from{opacity:0;transform:translateY(30px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}
</style>
<script>
/* ── empress-realtime-notify: new-order toast on all admin pages ── */
(function(){
  'use strict';
  var SSE_URL = 'index2.php?sse=1';
  var _lastId  = null;

  function showNewOrderToast(d) {
    var toast = document.getElementById('newOrderToast');
    var msg   = document.getElementById('noToastMsg');
    var badge = document.getElementById('noToastOrderBadge');
    var time  = document.getElementById('noToastTimeBadge');
    if (!toast) return;
    var lo = d.latestOrder || {};
    if (msg)   msg.textContent   = 'Table ' + (lo.table_no || '—') + ' — ₱' + parseFloat(lo.total_amt || 0).toLocaleString('en',{minimumFractionDigits:2});
    if (badge) badge.textContent = '#' + (lo.id || '');
    if (time)  time.textContent  = new Date().toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit',hour12:true});
    toast.style.display   = 'block';
    toast.style.animation = 'none';
    void toast.offsetWidth;
    toast.style.animation = 'toastSlideIn .35s cubic-bezier(.22,1,.36,1)';
    clearTimeout(toast._t);
    toast._t = setTimeout(function(){ toast.style.display='none'; }, 8000);
    /* beep */
    try {
      var ctx = new (window.AudioContext || window.webkitAudioContext)();
      var osc = ctx.createOscillator(); var g = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = 'sine'; osc.frequency.value = 880;
      g.gain.setValueAtTime(0.3, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
      osc.start(); osc.stop(ctx.currentTime + 0.4);
    } catch(e){}
  }

  function setDot(ok) {
    document.querySelectorAll('.rt-live-dot').forEach(function(el){
      el.style.background = ok ? '#22c55e' : '#ef4444';
      el.title = ok ? 'Live — connected' : 'Live — reconnecting…';
    });
  }

  function connect() {
    if (!window.EventSource) return;
    var es = new EventSource(SSE_URL);
    es.addEventListener('stats', function(e){
      try {
        var d = JSON.parse(e.data);
        setDot(true);
        if (_lastId === null) { _lastId = d.latestOrderId; return; }
        if (d.latestOrderId > _lastId) {
          _lastId = d.latestOrderId;
          showNewOrderToast(d);
        }
      } catch(ex){}
    });
    es.onerror = function(){ setDot(false); };
    es.onopen  = function(){ setDot(true);  };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', connect);
  } else {
    connect();
  }
})();
</script>
<!-- ══ END real-time notification ════════════════════════════════════ -->

</body>
</html>